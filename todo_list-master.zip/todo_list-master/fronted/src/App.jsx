import "./App.css";
import Todos from "./components/Todos";

function App() {
  return (
    <>
      <main>
        <Todos />
      </main>
    </>
  );
}

export default App;
